<div class="item-page-accordion">
<?php
	echo $this->item->_currentCustomField->value; 
?>
</div>