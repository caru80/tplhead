<?php
	defined('_JEXEC') or die();
	/*
		Leeres Template.
		
		Rendert eine Komponente, und macht sonst nix.
		
		CRu.: 2016-09-06
	*/
?>
<jdoc:include type="component" />